Chyper Engine — Media Kit
=========================

This ZIP contains basic press assets for Chyper Engine by Iron Signal Works.

Included:
- isw_logo.svg / isw_logo.png  → Iron Signal Works logo (placeholder)
- chyper_screenshot1.png       → App screenshot (placeholder)
- chyper_screenshot2.png       → App screenshot (placeholder)
- chyper_ascii_example.png     → ASCII export sample (placeholder)
- chyper_qr_example.png        → QR export sample (placeholder)
- Press kit PDFs

Please replace placeholders with actual captures before release.

Visit: https://ironsignalworks.com/chyper
